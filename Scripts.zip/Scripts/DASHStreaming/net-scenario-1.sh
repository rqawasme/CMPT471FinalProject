#!/usr/bin/env bash

SCRIPT=./

${SCRIPT}simulate-network.sh -i lo -c set -b 800kbit -d 2ms
