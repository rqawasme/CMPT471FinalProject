#!/usr/bin/env bash

SCRIPT=./

${SCRIPT}simulate-network.sh -i lo -c set -b 2500kbit -d 2ms

sleep 20
# reset network interface
${SCRIPT}simulate-network.sh -i lo -c reset

${SCRIPT}simulate-network.sh -i lo -c set -b 2000kbit -d 2ms

sleep 20
# reset network interface
${SCRIPT}simulate-network.sh -i lo -c reset

${SCRIPT}simulate-network.sh -i lo -c set -b 1500kbit -d 2ms


sleep 20
# reset network interface
${SCRIPT}simulate-network.sh -i lo -c reset

${SCRIPT}simulate-network.sh -i lo -c set -b 1000kbit -d 2ms
