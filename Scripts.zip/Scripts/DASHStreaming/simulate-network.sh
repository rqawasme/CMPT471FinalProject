#!/usr/bin/env bash


# lan 900Mbps, 0.3ms
# work-internet 90Mbps, 3.6ms
# home-internet ??Mbps, ??ms
# lte ??Mbps, 70ms
# 4g ??Mbps, 110ms
# 3g ??Mbps, 120ms

INTERFACE="lo"
PROFILE=""
COMMAND="reset"
BANDWIDTH=""
DELAY=""

profiles=( "lan" "work-internet" "home-internet" )
declare -A bws=( ["lan"]="900mbps" ["work-internet"]="90mbps" ["home-internet"]="15mbps")
declare -A delays=( ["lan"]="0.3ms" ["work-internet"]="3.6ms" ["home-internet"]="4.8ms")

function usage() {
    echo "Usage:"
    exit 0
}

function version() {
    echo "Version: 0.1"
    exit 0
}


function show_interface() {
    if [ ! -z $1 ]; then
        tc -s qdisc ls dev $1
    fi
}

function reset_interface() {
    if [ ! -z $1 ]; then
        tc qdisc del dev $1 root
    fi
}

function set_interface() {
    if [ ! -z $1 ] && [ ! -z $2 ] && [ ! -z $3 ]; then
        tc qdisc add dev $1 root handle 1: htb default 12
        tc class add dev $1 parent 1: classid 1:12 htb rate $2 ceil $2
        tc qdisc add dev $1 parent 1:12 netem delay $3
    fi
}

function set_bandwidth_delay() {
    if [ ! -z $1 ]; then
        BANDWIDTH="${bws["$1"]}"
        DELAY="${delays["$1"]}"
    fi
}

array_contains () {
    local array="$1[@]"
    local seeking=$2
    local in=1
    for element in "${!array}"; do
        if [[ ${element} == ${seeking} ]]; then
            in=0
            break
        fi
    done
    return ${in}
}

function initialize() {
    PROFILE_CONTAINED=`array_contains profiles ${PROFILE}  && echo "1" || echo "0"`

    if [ -z ${INTERFACE} ] || [ -z ${COMMAND} ]; then
        usage
    fi

    if [ "${COMMAND}" == "set" ] ; then
        if [ -z ${PROFILE} ] ; then
            if [ -z ${BANDWIDTH} ] || [ -z ${DELAY} ]; then
                echo "Profile is not set, (lan) profile is used"
                PROFILE="lan"
                set_bandwidth_delay ${PROFILE}
            fi
        else
            if [ "$PROFILE_CONTAINED" == "0" ]; then
                if [ -z ${BANDWIDTH} ] || [ -z ${DELAY} ]; then
                    echo "Profile is not correct, (lan) profile is used"
                    PROFILE="lan"
                    set_bandwidth_delay ${PROFILE}
                fi
            else
                set_bandwidth_delay ${PROFILE}
            fi
        fi
    fi
}

while [ $# -gt 0 ];
do
    case $1 in
    (-h|--help) usage ;;
    (-v|--version) version ;;
    (-i|--interface)
        INTERFACE=$2;
        shift 2;;
    (-c|--command)
        COMMAND=$2;
        shift 2;;
    (-b|--bandwidth)
        BANDWIDTH=$2;
        shift 2;;
    (-d|--delay)
        DELAY=$2;
        shift 2;;
    (-p|--profile)
        PROFILE=$2;
        shift 2;;
    (--) shift; break;;
    (-*) echo "$1: unknown option"; usage ;;
    (*) break;;
    esac
done

initialize

if [ "$COMMAND" == "reset" ]; then
    reset_interface ${INTERFACE}
fi

if [ "$COMMAND" == "set" ]; then
    set_interface ${INTERFACE} ${BANDWIDTH} ${DELAY}
fi

if [ "$COMMAND" == "show" ]; then
    show_interface ${INTERFACE}
fi



